import React from 'react'
import Head from 'next/head'

const Login = (props) => {
  return (
    <>
      <div className="login-container">
        <Head>
          <title>exported project</title>
        </Head>
        <div className="login-login">
          <div className="login-frame6134">
            <span className="login-text 18Medium">
              <span>Don&apos;t have a Rifiz account?</span>
            </span>
            <span className="login-text02 18Medium">
              <span>Sign up</span>
            </span>
          </div>
          <div className="login-frame6171">
            <span className="login-text04 18Medium">
              <span>Reset passwp</span>
            </span>
            <span className="login-text06 18Medium">
              <span>Sign up</span>
            </span>
          </div>
          <div className="login-group67">
            <div className="login-group65">
              <img
                alt="Rectangle6830375"
                src="/playground_assets/rectangle6830375-qv3m.svg"
                className="login-rectangle683"
              />
              <img
                alt="IconGoogle0381"
                src="/playground_assets/icongoogle0381-i39.svg"
                className="login-icon-google"
              />
            </div>
            <div className="login-group66">
              <img
                alt="IconApple0382"
                src="/playground_assets/iconapple0382-lwja.svg"
                className="login-icon-apple"
              />
            </div>
            <div className="login-group64">
              <img
                alt="IconFacebook0380"
                src="/playground_assets/iconfacebook0380-9c7q.svg"
                className="login-icon-facebook"
              />
            </div>
          </div>
          <img
            alt="Logo0383"
            src="/playground_assets/logo0383-d4zr-200h.png"
            className="login-logo"
          />
          <div className="login-frame6135">
            <div className="login-headline">
              <span className="login-text08 32Extrabold">
                <span>Login</span>
              </span>
              <div className="login-supporting">
                <span className="login-text10 16Regular">
                  <span>Free forever. No payment needed.</span>
                </span>
              </div>
            </div>
            <div className="login-form">
              <div className="login-component13">
                <div className="login-frame6130">
                  <span className="login-text12 14Medium">
                    <span>Username</span>
                  </span>
                  <span className="login-text14 14Medium">*</span>
                </div>
                <div className="login-frame6131">
                  <img
                    alt="Rectangle538I215"
                    src="/playground_assets/rectangle538i215-wfn6-200h.png"
                    className="login-rectangle538"
                  />
                  <span className="login-text15 18Medium">
                    <span>User name</span>
                  </span>
                </div>
              </div>
              <div className="login-component15">
                <div className="login-frame61301">
                  <span className="login-text17 14Medium">
                    <span>Password</span>
                  </span>
                </div>
                <div className="login-frame61311">
                  <img
                    alt="Rectangle538I215"
                    src="/playground_assets/rectangle538i215-jg3l-200h.png"
                    className="login-rectangle5381"
                  />
                  <div className="login-eye">
                    <img
                      alt="EyeoffI215"
                      src="/playground_assets/eyeoffi215-v4vl.svg"
                      className="login-eyeoff"
                    />
                  </div>
                  <span className="login-text19 18Medium">
                    <span>Password</span>
                  </span>
                </div>
              </div>
              <div className="login-frame6133">
                <div className="login-component16">
                  <span className="login-text21 20Bold">
                    <span>Login</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <style jsx>
        {`
          .login-container {
            min-height: 100vh;
          }
          .login-login {
            width: 100%;
            height: 1080px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-items: flex-start;
            flex-shrink: 0;
            border-color: transparent;
            background-color: rgba(249, 249, 249, 1);
          }
          .login-frame6134 {
            top: 769px;
            left: 798px;
            width: 295px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            border-color: transparent;
          }
          .login-text {
            color: var(--dl-color-default-black);
            height: auto;
            align-self: auto;
            text-align: center;
            line-height: 28px;
            margin-right: 4px;
            margin-bottom: 0;
          }
          .login-text02 {
            color: var(--dl-color-default-purple);
            height: auto;
            align-self: auto;
            text-align: center;
            line-height: 28px;
            margin-right: 0;
            margin-bottom: 0;
          }
          .login-frame6171 {
            top: 826px;
            left: 794px;
            width: 187px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            border-color: transparent;
          }
          .login-text04 {
            color: var(--dl-color-default-black);
            height: auto;
            align-self: auto;
            text-align: center;
            line-height: 28px;
            margin-right: 4px;
            margin-bottom: 0;
          }
          .login-text06 {
            color: var(--dl-color-default-purple);
            height: auto;
            align-self: auto;
            text-align: center;
            line-height: 28px;
            margin-right: 0;
            margin-bottom: 0;
          }
          .login-group67 {
            top: 688px;
            left: 720px;
            width: 480px;
            height: 52px;
            display: flex;
            padding: 0;
            position: absolute;
            align-self: auto;
            box-sizing: border-box;
            align-items: flex-start;
            flex-shrink: 1;
            border-color: transparent;
            border-style: none;
            border-width: 0;
            margin-right: 0;
            border-radius: 0px 0px 0px 0px;
            margin-bottom: 0;
            flex-direction: row;
            justify-content: flex-start;
            background-color: transparent;
          }
          .login-group65 {
            top: 0px;
            left: 166px;
            width: 148px;
            height: 52px;
            display: flex;
            padding: 0;
            position: absolute;
            align-self: auto;
            box-sizing: border-box;
            align-items: flex-start;
            flex-shrink: 1;
            border-color: transparent;
            border-style: none;
            border-width: 0;
            border-radius: 0px 0px 0px 0px;
            flex-direction: row;
            justify-content: flex-start;
            background-color: transparent;
          }
          .login-rectangle683 {
            top: 0px;
            left: 0px;
            width: 148px;
            height: 52px;
            position: absolute;
          }
          .login-icon-google {
            top: 14px;
            left: 62px;
            width: 24px;
            height: 24px;
            position: absolute;
          }
          .login-group66 {
            top: 0px;
            left: 332px;
            width: 148px;
            height: 52px;
            display: flex;
            padding: 0;
            position: absolute;
            align-self: auto;
            box-sizing: border-box;
            align-items: flex-start;
            flex-shrink: 1;
            border-color: transparent;
            border-style: none;
            border-width: 0;
            border-radius: 0px 0px 0px 0px;
            flex-direction: row;
            justify-content: flex-start;
            background-color: rgba(0, 0, 0, 1);
          }
          .login-icon-apple {
            top: 14px;
            left: 62px;
            width: 24px;
            height: 24px;
            position: absolute;
          }
          .login-group64 {
            top: 0px;
            left: 0px;
            width: 148px;
            height: 52px;
            display: flex;
            padding: 0;
            position: absolute;
            align-self: auto;
            box-sizing: border-box;
            align-items: flex-start;
            flex-shrink: 1;
            border-color: transparent;
            border-style: none;
            border-width: 0;
            border-radius: 0px 0px 0px 0px;
            flex-direction: row;
            justify-content: flex-start;
            background-color: rgba(24, 119, 242, 1);
          }
          .login-icon-facebook {
            top: 14px;
            left: 62px;
            width: 24px;
            height: 24px;
            position: absolute;
          }
          .login-logo {
            top: 226px;
            left: 881px;
            width: 135px;
            height: 44px;
            position: absolute;
            border-color: transparent;
          }
          .login-frame6135 {
            top: 299px;
            left: 720px;
            width: 480px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            border-color: transparent;
            flex-direction: column;
          }
          .login-headline {
            display: flex;
            position: relative;
            align-items: flex-start;
            border-color: transparent;
            margin-bottom: 40px;
            flex-direction: column;
          }
          .login-text08 {
            color: var(--dl-color-gray-900);
            height: auto;
            align-self: auto;
            text-align: center;
            line-height: 36px;
            margin-right: 0;
            margin-bottom: 8px;
          }
          .login-supporting {
            display: flex;
            position: relative;
            align-items: center;
            border-color: transparent;
          }
          .login-text10 {
            color: var(--dl-color-gray-600);
            height: auto;
            align-self: auto;
            text-align: left;
            line-height: 24px;
            margin-right: 0;
            margin-bottom: 0;
          }
          .login-form {
            display: flex;
            position: relative;
            align-items: center;
            border-color: transparent;
            flex-direction: column;
            justify-content: center;
          }
          .login-component13 {
            width: 480px;
            display: flex;
            position: relative;
            align-items: flex-start;
            flex-shrink: 0;
            border-color: transparent;
            margin-bottom: 24px;
            flex-direction: column;
          }
          .login-frame6130 {
            display: flex;
            position: relative;
            align-items: center;
            border-color: transparent;
            margin-bottom: 8px;
          }
          .login-text12 {
            color: var(--dl-color-default-black);
            height: auto;
            align-self: auto;
            text-align: left;
            line-height: 16px;
            margin-right: 4px;
            margin-bottom: 0;
          }
          .login-text14 {
            color: var(--dl-color-default-red);
            height: auto;
            align-self: auto;
            text-align: left;
            line-height: 16px;
            margin-right: 0;
            margin-bottom: 0;
          }
          .login-frame6131 {
            width: 480px;
            height: 52px;
            display: flex;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            border-color: transparent;
          }
          .login-rectangle538 {
            top: 0px;
            left: 0px;
            width: 480px;
            height: 52px;
            position: absolute;
            border-color: transparent;
            border-radius: 20px;
          }
          .login-text15 {
            top: 12px;
            left: 16px;
            color: var(--dl-color-default-subcontent);
            height: auto;
            position: absolute;
            align-self: auto;
            text-align: left;
            line-height: 28px;
            margin-right: 0;
            margin-bottom: 0;
          }
          .login-component15 {
            width: 480px;
            display: flex;
            position: relative;
            align-items: flex-start;
            flex-shrink: 0;
            border-color: transparent;
            margin-bottom: 24px;
            flex-direction: column;
          }
          .login-frame61301 {
            display: flex;
            position: relative;
            align-items: center;
            border-color: transparent;
            margin-bottom: 8px;
          }
          .login-text17 {
            color: var(--dl-color-default-black);
            height: auto;
            align-self: auto;
            text-align: left;
            line-height: 16px;
            margin-right: 0;
            margin-bottom: 0;
          }
          .login-frame61311 {
            width: 480px;
            height: 52px;
            display: flex;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            border-color: transparent;
          }
          .login-rectangle5381 {
            top: 0px;
            left: 0px;
            width: 480px;
            height: 52px;
            position: absolute;
            border-color: transparent;
            border-radius: 20px;
          }
          .login-eye {
            top: 14px;
            left: 440px;
            width: 24px;
            height: 24px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            border-color: transparent;
          }
          .login-eyeoff {
            top: 0px;
            left: 0px;
            width: 24px;
            height: 24px;
            position: absolute;
          }
          .login-text19 {
            top: 12px;
            left: 16px;
            color: var(--dl-color-default-subcontent);
            height: auto;
            position: absolute;
            align-self: auto;
            text-align: left;
            line-height: 28px;
            margin-right: 0;
            margin-bottom: 0;
          }
          .login-frame6133 {
            display: flex;
            position: relative;
            align-items: center;
            border-color: transparent;
            flex-direction: column;
            justify-content: center;
          }
          .login-component16 {
            width: 480px;
            display: flex;
            padding: 12px 48px;
            position: relative;
            align-items: center;
            flex-shrink: 0;
            border-color: transparent;
            border-radius: 15px;
            justify-content: center;
            background-color: rgba(87, 58, 232, 1);
          }
          .login-text21 {
            color: rgba(255, 255, 255, 1);
            height: auto;
            align-self: auto;
            text-align: center;
            line-height: 28px;
            margin-right: 0;
            margin-bottom: 0;
          }
        `}
      </style>
    </>
  )
}

export default Login
